import React, { useState } from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import ToDoList from './ToDoList';
import ToDoForm from './ToDoForm';

function App() {
  const [tasks, setTasks] = useState([
    { id: 1, task: "Do laundry", completed: true },
    { id: 2, task: "Go to gym", completed: false },
    { id: 3, task: "Walk dog", completed: true }
  ]);
  
  const [newTask, setNewTask] = useState("");

  const addTask = () => {
    if (newTask.trim()) {
      setTasks((prevTasks) => [
        ...prevTasks,
        { id: prevTasks.length + 1, task: newTask, completed: false }
      ]);
      setNewTask("");
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Pass tasks and addTask to ToDoList */}
      <ToDoList tasks={tasks} />
      {/* Pass newTask, setNewTask, and addTask to ToDoForm */}
      <ToDoForm newTask={newTask} setNewTask={setNewTask} addTask={addTask} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
  },
});

export default App;
